
import java.util.Scanner;


public class entradasusuario {

public static void main(String[] args)
    {
        // Declarar el objeto e inicializar con
        // el objeto de entrada estándar predefinido

        Scanner sc = new Scanner(System.in);
	System.out.print("Nombre:");
        // entrada de una cadena
        String name = sc.nextLine();

        // entrada de un carácter
        char gender = sc.next().charAt(0);

        // Entrada de datos numéricos
        // byte, short y float
        int age = sc.nextInt();
        long mobileNo = sc.nextLong();
        double average = sc.nextDouble();

        // Imprima los valores para verificar si la entrada
        // fue obtenida correctamente.
        System.out.println("Nombre: "+name);
        System.out.println("Genero: "+gender);
        System.out.println("Edad: "+age);
        System.out.println("Telefono: "+mobileNo);
        System.out.println("Promedio: "+average);
    }
}
